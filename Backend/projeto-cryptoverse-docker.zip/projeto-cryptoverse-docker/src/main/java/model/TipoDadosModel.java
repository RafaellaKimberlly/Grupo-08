package model;

public class TipoDadosModel {

    private Integer idTipoDados;
    private String descDados;

    public Integer getIdTipoDados() {
        return idTipoDados;
    }

    public void setIdTipoDados(Integer idTipoDados) {
        this.idTipoDados = idTipoDados;
    }

    public String getDescDados() {
        return descDados;
    }

    public void setDescDados(String descDados) {
        this.descDados = descDados;
    }
}
